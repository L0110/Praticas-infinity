produtos = []

clientes = []

pedidos = []